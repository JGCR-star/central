package com.example.laboratorioucv.myapplication.data;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class LawyersDbHelper extends SQLiteOpenHelper {

    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "Lawyers.db";

    public LawyersDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + LawyersContract.LawyerEntry.TABLE_NAME + " ("
                + LawyersContract.LawyerEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + LawyersContract.LawyerEntry.ID + " TEXT NOT NULL,"
                + LawyersContract.LawyerEntry.NAME + " TEXT NOT NULL,"
                + LawyersContract.LawyerEntry.SPECIALTY + " TEXT NOT NULL,"
                + LawyersContract.LawyerEntry.PHONE_NUMBER + " TEXT NOT NULL,"
                + LawyersContract.LawyerEntry.BIO + " TEXT NOT NULL,"
                + LawyersContract.LawyerEntry.AVATAR_URI + " TEXT,"
                + "UNIQUE (" + LawyersContract.LawyerEntry.ID + "))");

        // INSERTAR DATOS DE LA TABLA
        mockData(db);

    }

    private void mockData(SQLiteDatabase sqLiteDatabase) {
        mockLawyer(sqLiteDatabase, new Lawyer("Tatiana Gil", "Abogado penalista",
                "58974583", "Profesional con 5 años de experiencia.",
                "tatiana.jpg"));
        mockLawyer(sqLiteDatabase, new Lawyer("Spencer Flores", "Abogado de accidentes",
                "528745845", "Profesional con 13 años.",
                "spencer.jpg"));
        mockLawyer(sqLiteDatabase, new Lawyer("Edith Pillaca", "Abogado de colegios",
                "8966744515", "Profesional en defender alumnos.",
                "edith.jpg"));
        mockLawyer(sqLiteDatabase, new Lawyer("Maximo Gil", "Abogado en lenguas",
                "845896324 ", "Profesional con 10 años de experiencia.",
                "maximo.jpg"));
        mockLawyer(sqLiteDatabase, new Lawyer("Hector Sanson", "Abogado de las venecas",
                "2698569421", "Profesional en defender a las venecas.",
                "hector.jpg"));
        mockLawyer(sqLiteDatabase, new Lawyer("Estrella Quiroz", "Abogado de colegios",
                "16548745484", "Profesional en defender alumnos.",
                "estrella.jpg"));
        mockLawyer(sqLiteDatabase, new Lawyer("Josefa Quiroz", "Abogado de colegios",
                "16548745484", "Profesional en defender alumnos.",
                "josefa.jpg"));
        mockLawyer(sqLiteDatabase, new Lawyer("Valentina Mia", "Abogado de colegios",
                "16548745484", "Profesional en defender alumnos.",
                "valentina.jpg"));
        mockLawyer(sqLiteDatabase, new Lawyer("Miss Quiroz", "Abogado de colegios",
                "16548745484", "Profesional en defender alumnos.",
                "miss.jpg"));
        mockLawyer(sqLiteDatabase, new Lawyer("Mercedes Uribe", "Abogado de colegios",
                "16548745484", "Profesional en defender alumnos.",
                "mercedes.jpg"));


    }

    public long mockLawyer(SQLiteDatabase db, Lawyer lawyer) {
        return db.insert(LawyersContract.LawyerEntry.TABLE_NAME,
                null, lawyer.toContentValues());

    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //NO HAY NADA
    }
    public long saveLawyer(Lawyer lawyer) {
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        return sqLiteDatabase.insert( LawyersContract.LawyerEntry.TABLE_NAME,
                null,lawyer.toContentValues());
    }
    public Cursor getAllLawyers() {
        return getReadableDatabase().query(LawyersContract.LawyerEntry.TABLE_NAME,null,null,
                null,null,null, null);
    }
    public Cursor getLawyerById(String lawyerId) {
        Cursor c = getReadableDatabase().query( LawyersContract.LawyerEntry.TABLE_NAME,null,
                LawyersContract.LawyerEntry.ID + " LIKE ?",
                new String[]{lawyerId},null, null,null);
        return c;

    }
    public int deleteLawyer(String lawyerId){

        return getWritableDatabase().delete(LawyersContract.LawyerEntry.TABLE_NAME,
                LawyersContract.LawyerEntry.ID + " LIKE ?",
                new String[]{lawyerId});

    }
    public int updateLawyer(Lawyer lawyer, String lawyerId) {
        return getWritableDatabase().update(LawyersContract.LawyerEntry.TABLE_NAME,
                lawyer.toContentValues(),
                LawyersContract.LawyerEntry.ID + " LIKE ?",
                new String[]{lawyerId}

        );
    }
}
