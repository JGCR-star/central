package com.example.laboratorioucv.myapplication.lawyers;

public class LawyersActivity {
}
