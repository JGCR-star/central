package com.example.laboratorioucv.myapplication.lawyers;

public class LawyerFragment {
}
