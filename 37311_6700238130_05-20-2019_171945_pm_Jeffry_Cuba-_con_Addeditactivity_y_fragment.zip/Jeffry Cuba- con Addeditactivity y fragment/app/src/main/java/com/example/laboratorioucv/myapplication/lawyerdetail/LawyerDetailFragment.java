package com.example.laboratorioucv.myapplication.lawyerdetail;

public class LawyerDetailFragment {
}
