package com.example.laboratorioucv.myapplication.data;



import android.content.ContentValues;
import android.database.Cursor;
import java.util.UUID;

/* Entidad Abogado*/

public class Lawyer {
    private String id;
    private String name;
    private String spaecialty;
    private String phone;
    private String bio;
    private String avatarUri;

    public Lawyer(String name, String spaecialty, String phone, String bio, String avatarUri){

        this.id = UUID.randomUUID().toString();
        this.name = name;
        this.spaecialty = spaecialty;
        this.phone = phone;
        this.bio = bio;
        this.avatarUri = avatarUri;
    }

//

    public Lawyer(Cursor cursor){

        id = cursor.getString(cursor.getColumnIndex(LawyersEntry.ID));

        name = cursor.getString(cursor.getColumnIndex(LawyersEntry.NAME));

        spaecialty = cursor.getString(cursor.getColumnIndex(LawyersEntry.SPECIALTY));

        phone = cursor.getString(cursor.getColumnIndex(LawyersEntry.PHONENUMBER));

        bio = cursor.getString(cursor.getColumnIndex(LawyersEntry.BIO));

        Avatar_Uri = cursor.getString(cursor.getColumnIndex(LawyersEntry.AVATAR_URI));

    }


    public ContentValues toContentValues(){

        ContentValues values = new ContentValues();
        values.put(LawyersEntry.ID,id);
        values.put(LawyersEntry.NAME,name);
        values.put(LawyersEntry.SPECIALTY,spaecialty);
        values.put(LawyersEntry.PHONE_NUMBER,phone);
        values.put(LawyersEntry.BIO,bio);
        values.put(LawyersEntry.AVATAR_URI,avatarUri);
        return values;

    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getSpecialty() { return spaecialty; }
    public String getPhonenumber() { return phone; }
    public String getBio() { return bio; }
    public String getAvatarUri() { return avatarUri; }
}
